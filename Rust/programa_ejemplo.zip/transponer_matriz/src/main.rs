//Fin en mente: Poner a prueba los conocimientos de álgebra lineal y programación
//Nombre del proyecto: transponer_matriz
//Nombre del programador: Allyson Dulce Abigail Escobar Sandoval
//Descripcion:Realizar un programa que permita generar una matriz cuadrada de n elementos y la convierta en la matriz transpuesta.
//Recursos:rustc 1.93.0 y cargo 1.93.0
//Lenguaje:Rust
//Ajustes pendientes:ninguno
//Fecha de modificaciones:ninguno
//Fecha de creacion: 16/3/2026

///////////////////////////////////////////////////
//para ejecutarlo escribir en consola: cargo run///
//////////////////////////////////////////////////
/// 
//importar las librerías necesarias//
//de la librería de rand se va a utilizar el trait (reutilizar metodos en clases independientes) Rng que permite generar numeros aleatorios
use rand::Rng;
//es como en c++ que se usa io (entrada y salida) donde el self es el receptor de un método y el write permite mostrar información 
use std::io::{self, Write};

// Crea matriz usando iteradores
//para definir una función en rust se usa fn
//posteriormente se escribe el nombre que se le quiere dar a esa funcion}
//el parámetro que está usando y definiendo "n" recibe el tamaño de la matriz (el usize representa el tipo entero sin signo que tienen el mismo tamaño que un puntero)
//lo más raro es el Vec<Vec>i32>> que indica que es un vector de vectores (definicion de una matriz) de tipo enteros de 32 bits
fn crear_matriz(n: usize) -> Vec<Vec<i32>> {
    //aqui se general el número aleatorio
    //el let mut indica la declaracion de una variable mutable
    let mut rng = rand::thread_rng();
    //esto indica que el rango va de 0 hasta n-1, es como el generador de las filas de la matriz
    (0..n)
        //es una función a cada elemento del rango y el |_| indica que no se va a usar el valor del rando, solo se va a repetir n veces
        .map(|_| {
            //se crean los reglones de la matriz con la misma lógica que antes, pero cada vector que se cree estará dentro de una fila
            (0..n)
            //el =100 indica que el 100 se incluye en la generacion del numero aleatorio
                .map(|_| rng.gen_range(0..=100))
                //convierte los valores generados en un vector Vec<i32>
                .collect()
        })
        //lo mismo que antes
        .collect()
}

// Imprime matriz
//& significa referencia, no copia
fn mostrar_matriz(m: &[Vec<i32>]) {
    //recordemos que fila y reglon tiene el mismo tamaño
    //es como un for, en el que se itera para recorrer todos los elementos de la matriz
    m.iter().for_each(|fila| {
        //el :3 reserva espacios para alinear numeros
        fila.iter().for_each(|reglon| print!("{:3}, ", reglon));
        println!("\n----------------------------");
    });
}
// Transposición funcional (crea nueva matriz)
fn transponer(m: &[Vec<i32>]) -> Vec<Vec<i32>> {
    //obtiene el numero de filas de la matriz (y por consiguiente de reglones)
    let n = m.len();

    (0..n)
        .map(|fila| {
            (0..n)
            //cambio el orden para transponerla
                .map(|reglon| m[reglon][fila])
                //convierte los valores en una fila del nuevo vector
                .collect()
        })
        .collect()
}


fn main() {
    println!("-----TRANSPONER UNA MATRIZ-----");
    //defino el tamaño de mi matriz nxn
    //el usize es un entero sin signo
    let n = 4;
    //lamo a la funcion para crear la matriz
    let matriz = crear_matriz(n);
    //muestro mi matriz
    println!("\nMatriz original:\n");
    mostrar_matriz(&matriz);
    //mando la matriz (peros solo se usa la referencia) para transponerla y luego mostrarla
    let matriz_t = transponer(&matriz);

    println!("\nMatriz transpuesta:\n");
    mostrar_matriz(&matriz_t);
}
